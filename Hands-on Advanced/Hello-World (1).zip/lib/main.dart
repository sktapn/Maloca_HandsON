import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://rcddasfiruszqnaltqnc.supabase.co', // Verifique isso!
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJjZGRhc2ZpcnVzenFuYWx0cW5jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE4NzUyODIsImV4cCI6MjA1NzQ1MTI4Mn0.Lfx4gar3JBrt1TSEW3nrRNN3HQiVkJhHxK2BcQ5kW-g', // Verifique isso!
  );

  runApp(const MedicalApp());
}

final supabase = Supabase.instance.client;

class MedicalApp extends StatelessWidget {
  const MedicalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MediConnect',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E88E5),
          secondary: const Color(0xFF26A69A),
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

// Extension para mostrar SnackBar facilmente em qualquer contexto
extension ContextExtension on BuildContext {
  void showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(this).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError
            ? Theme.of(this).colorScheme.error
            : Theme.of(this).colorScheme.secondary,
      ),
    );
  }
}
