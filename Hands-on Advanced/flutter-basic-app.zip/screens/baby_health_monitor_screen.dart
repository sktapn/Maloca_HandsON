import 'package:flutter/material.dart';
import 'dart:ui';

class BabyHealthMonitorScreen extends StatefulWidget {
  const BabyHealthMonitorScreen({super.key});

  @override
  State<BabyHealthMonitorScreen> createState() => _BabyHealthMonitorScreenState();
}

class _BabyHealthMonitorScreenState extends State<BabyHealthMonitorScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text('Monitoramento de Saúde'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Color(0xFF0277BD),
          unselectedLabelColor: Colors.grey,
          indicatorColor: Color(0xFF0277BD),
          tabs: [
            Tab(text: 'Geral'),
            Tab(text: 'Peso'),
            Tab(text: 'Sono'),
            Tab(text: 'Alimentação'),
          ],
        ),
      ),
      body: Stack(
        children: [
          // Medical pattern background
          Positioned.fill(
            child: CustomPaint(
              painter: MedicalPatternPainter(),
            ),
          ),
          
          TabBarView(
            controller: _tabController,
            children: [
              // Geral tab
              _buildGeneralTab(),
              
              // Peso tab
              _buildWeightTab(),
              
              // Sono tab
              _buildSleepTab(),
              
              // Alimentação tab
              _buildFeedingTab(),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFF0277BD),
        child: Icon(Icons.add, color: Colors.white),
        onPressed: () {
          _showAddDataDialog();
        },
      ),
    );
  }
  
  Widget _buildGeneralTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Resumo de Saúde'),
          SizedBox(height: 16),
          
          // Stats cards
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  icon: Icons.monitor_weight_outlined,
                  title: 'Peso',
                  value: '3.8 kg',
                  change: '+0.2 kg',
                  isPositive: true,
                  color: Color(0xFF0277BD),
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: _buildStatCard(
                  icon: Icons.height,
                  title: 'Altura',
                  value: '52 cm',
                  change: '+1.5 cm',
                  isPositive: true,
                  color: Color(0xFF00BCD4),
                ),
              ),
            ],
          ),
          
          SizedBox(height: 16),
          
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  icon: Icons.nightlight_outlined,
                  title: 'Sono',
                  value: '14h/dia',
                  change: 'Normal',
                  isPositive: true,
                  color: Color(0xFF9C27B0),
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: _buildStatCard(
                  icon: Icons.thermostat_outlined,
                  title: 'Temperatura',
                  value: '36.5°C',
                  change: 'Normal',
                  isPositive: true,
                  color: Color(0xFF4CAF50),
                ),
              ),
            ],
          ),
          
          SizedBox(height: 24),
          _buildSectionTitle('Atividades Recentes'),
          SizedBox(height: 16),
          
          // Recent activities
          _buildActivityItem(
            icon: Icons.restaurant,
            title: 'Alimentação',
            description: 'Amamentação - 15 minutos',
            time: 'Hoje, 10:30',
            color: Color(0xFFFF9800),
          ),
          
          _buildActivityItem(
            icon: Icons.baby_changing_station,
            title: 'Troca de Fralda',
            description: 'Fralda molhada',
            time: 'Hoje, 10:00',
            color: Color(0xFF3F51B5),
          ),
          
          _buildActivityItem(
            icon: Icons.nightlight_outlined,
            title: 'Sono',
            description: '2 horas de sono',
            time: 'Hoje, 07:30',
            color: Color(0xFF9C27B0),
          ),
          
          _buildActivityItem(
            icon: Icons.monitor_weight_outlined,
            title: 'Peso',
            description: 'Pesagem semanal: 3.8 kg',
            time: 'Ontem, 09:15',
            color: Color(0xFF0277BD),
          ),
          
          SizedBox(height: 24),
          _buildSectionTitle('Próximos Marcos'),
          SizedBox(height: 16),
          
          // Milestones
          _buildMilestoneItem(
            title: 'Sorrir socialmente',
            description: 'Esperado entre 1-2 meses',
            progress: 0.7,
            color: Color(0xFF4CAF50),
          ),
          
          _buildMilestoneItem(
            title: 'Segurar a cabeça',
            description: 'Esperado entre 2-4 meses',
            progress: 0.3,
            color: Color(0xFF00BCD4),
          ),
          
          _buildMilestoneItem(
            title: 'Rolar',
            description: 'Esperado entre 4-6 meses',
            progress: 0.1,
            color: Color(0xFF0277BD),
          ),
          
          SizedBox(height: 40),
        ],
      ),
    );
  }
  
  Widget _buildWeightTab() {
    return Center(
      child: Text(
        'Gráfico de peso em desenvolvimento',
        style: TextStyle(fontSize: 16, color: Colors.grey[600]),
      ),
    );
  }
  
  Widget _buildSleepTab() {
    return Center(
      child: Text(
        'Gráfico de sono em desenvolvimento',
        style: TextStyle(fontSize: 16, color: Colors.grey[600]),
      ),
    );
  }
  
  Widget _buildFeedingTab() {
    return Center(
      child: Text(
        'Gráfico de alimentação em desenvolvimento',
        style: TextStyle(fontSize: 16, color: Colors.grey[600]),
      ),
    );
  }
  
  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Color(0xFF333333),
      ),
    );
  }
  
  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required String change,
    required bool isPositive,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 20,
                ),
              ),
              SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 14,
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Text(
            value,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: Color(0xFF333333),
            ),
          ),
          SizedBox(height: 4),
          Row(
            children: [
              Icon(
                isPositive ? Icons.arrow_upward : Icons.arrow_downward,
                color: isPositive ? Color(0xFF4CAF50) : Colors.red,
                size: 14,
              ),
              SizedBox(width: 4),
              Text(
                change,
                style: TextStyle(
                  color: isPositive ? Color(0xFF4CAF50) : Colors.red,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildActivityItem({
    required IconData icon,
    required String title,
    required String description,
    required String time,
    required Color color,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Color(0xFF333333),
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  description,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          Text(
            time,
            style: TextStyle(
              color: Colors.grey[500],
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildMilestoneItem({
    required String title,
    required String description,
    required double progress,
    required Color color,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 14,
              color: Color(0xFF333333),
            ),
          ),
          SizedBox(height: 4),
          Text(
            description,
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 13,
            ),
          ),
          SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(3),
            ),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.grey[200],
              valueColor: AlwaysStoppedAnimation<Color>(color),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }
  
  void _showAddDataDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Adicionar Registro'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'Tipo de Registro',
                border: OutlineInputBorder(),
              ),
              items: [
                DropdownMenuItem(value: 'weight', child: Text('Peso')),
                DropdownMenuItem(value: 'height', child: Text('Altura')),
                DropdownMenuItem(value: 'sleep', child: Text('Sono')),
                DropdownMenuItem(value: 'feeding', child: Text('Alimentação')),
                DropdownMenuItem(value: 'diaper', child: Text('Fralda')),
                DropdownMenuItem(value: 'temperature', child: Text('Temperatura')),
              ],
              onChanged: (value) {},
            ),
            SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                labelText: 'Valor',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                labelText: 'Observações',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF0277BD),
            ),
            child: Text('Salvar'),
          ),
        ],
      ),
    );
  }
}

class MedicalPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF0277BD).withOpacity(0.1)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final spacing = 40.0;
    
    // Draw plus symbols pattern
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        // Horizontal line
        canvas.drawLine(
          Offset(x - 5, y),
          Offset(x + 5, y),
          paint,
        );
        
        // Vertical line
        canvas.drawLine(
          Offset(x, y - 5),
          Offset(x, y + 5),
          paint,
        );
      }
    }
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

