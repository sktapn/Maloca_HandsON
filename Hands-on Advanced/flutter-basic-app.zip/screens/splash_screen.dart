import 'package:flutter/material.dart';
import 'dart:ui';
import 'dart:math' as math;
import 'login_screen.dart';
import 'welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Interval(0.0, 0.6, curve: Curves.easeIn),
      ),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Interval(0.2, 0.8, curve: Curves.easeOutBack),
      ),
    );

    _controller.forward();

    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const WelcomeScreen()),
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      body: Stack(
        children: [
          // Medical pattern background
          Positioned.fill(
            child: CustomPaint(
              painter: MedicalPatternPainter(),
            ),
          ),
          
          // Subtle wave decoration
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: WavePainter(
                colors: [
                  Color(0xFF0277BD).withOpacity(0.15),
                  Color(0xFF00BCD4).withOpacity(0.15),
                ],
              ),
              size: Size(MediaQuery.of(context).size.width, 300),
            ),
          ),
          
          // Bottom wave decoration
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: BottomWavePainter(
                colors: [
                  Color(0xFF00BCD4).withOpacity(0.15),
                  Color(0xFF4CAF50).withOpacity(0.15),
                ],
              ),
              size: Size(MediaQuery.of(context).size.width, 300),
            ),
          ),
          
          // Heartbeat line animation
          Positioned(
            top: MediaQuery.of(context).size.height * 0.4,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: HeartbeatLinePainter(
                progress: _controller.value,
                color: Color(0xFF0277BD).withOpacity(0.2),
              ),
              size: Size(MediaQuery.of(context).size.width, 50),
            ),
          ),
          
          // Content
          Center(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return FadeTransition(
                  opacity: _fadeAnimation,
                  child: ScaleTransition(
                    scale: _scaleAnimation,
                    child: child,
                  ),
                );
              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Logo
                  Image.network(
                    'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/babysafe_logo-Uhgxgs9VY2FbBx4YgJZGZlFptk5Vk7.png',
                    height: 200,
                    width: 200,
                  ),
                  SizedBox(height: 30),
                  
                  // Tagline with medical focus
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Color(0xFF4CAF50).withOpacity(0.08),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Text(
                      'Monitoramento de saúde infantil',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xFF4CAF50),
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  
                  SizedBox(height: 40),
                  
                  // Loading indicator
                  SizedBox(
                    width: 40,
                    height: 40,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF00BCD4)),
                      strokeWidth: 3,
                      backgroundColor: Color(0xFF00BCD4).withOpacity(0.2),
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Health icons
          ..._buildHealthIcons(),
        ],
      ),
    );
  }

  List<Widget> _buildHealthIcons() {
    final icons = [
      _HealthIcon(
        icon: Icons.favorite,
        color: Color(0xFF0277BD),
        position: Offset(50, 150),
        size: 20,
      ),
      _HealthIcon(
        icon: Icons.monitor_heart,
        color: Color(0xFF00BCD4),
        position: Offset(MediaQuery.of(context).size.width - 70, 180),
        size: 24,
      ),
      _HealthIcon(
        icon: Icons.health_and_safety,
        color: Color(0xFF4CAF50),
        position: Offset(80, MediaQuery.of(context).size.height - 150),
        size: 22,
      ),
      _HealthIcon(
        icon: Icons.medical_services,
        color: Color(0xFF0277BD),
        position: Offset(MediaQuery.of(context).size.width - 100, MediaQuery.of(context).size.height - 180),
        size: 18,
      ),
    ];
    
    return icons;
  }
}

class _HealthIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  final Offset position;
  final double size;

  const _HealthIcon({
    required this.icon,
    required this.color,
    required this.position,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: position.dx,
      top: position.dy,
      child: Opacity(
        opacity: 0.15,
        child: Icon(
          icon,
          color: color,
          size: size,
        ),
      ),
    );
  }
}

class MedicalPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF0277BD).withOpacity(0.1)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final spacing = 40.0;
    
    // Draw plus symbols pattern
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        // Horizontal line
        canvas.drawLine(
          Offset(x - 5, y),
          Offset(x + 5, y),
          paint,
        );
        
        // Vertical line
        canvas.drawLine(
          Offset(x, y - 5),
          Offset(x, y + 5),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class WavePainter extends CustomPainter {
  final List<Color> colors;

  WavePainter({required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: colors,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;
    
    final path = Path();
    
    path.moveTo(0, 0);
    path.lineTo(0, size.height * 0.5);
    
    // First wave
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height * 0.4,
      size.width * 0.5,
      size.height * 0.5,
    );
    
    // Second wave
    path.quadraticBezierTo(
      size.width * 0.75,
      size.height * 0.6,
      size.width,
      size.height * 0.5,
    );
    
    path.lineTo(size.width, 0);
    path.close();
    
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class BottomWavePainter extends CustomPainter {
  final List<Color> colors;

  BottomWavePainter({required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: colors,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;
    
    final path = Path();
    
    path.moveTo(0, size.height);
    path.lineTo(0, size.height * 0.5);
    
    // First wave
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height * 0.6,
      size.width * 0.5,
      size.height * 0.5,
    );
    
    // Second wave
    path.quadraticBezierTo(
      size.width * 0.75,
      size.height * 0.4,
      size.width,
      size.height * 0.5,
    );
    
    path.lineTo(size.width, size.height);
    path.close();
    
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class HeartbeatLinePainter extends CustomPainter {
  final double progress;
  final Color color;

  HeartbeatLinePainter({
    required this.progress,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;
    
    final path = Path();
    
    // Start at the left edge
    path.moveTo(0, size.height / 2);
    
    // Calculate how far along the path to draw based on progress
    final endX = size.width * progress;
    
    // Draw a flat line for the first segment
    path.lineTo(size.width * 0.2, size.height / 2);
    
    // Only draw the heartbeat pattern if we've progressed far enough
    if (progress > 0.2) {
      // First spike up
      path.lineTo(size.width * 0.3, size.height * 0.3);
      
      // Down to baseline
      path.lineTo(size.width * 0.35, size.height / 2);
      
      // Major spike up and down (heartbeat)
      if (progress > 0.35) {
        path.lineTo(size.width * 0.4, size.height * 0.1);
        path.lineTo(size.width * 0.45, size.height * 0.9);
        path.lineTo(size.width * 0.5, size.height / 2);
      }
      
      // Flat line
      if (progress > 0.5) {
        path.lineTo(size.width * 0.7, size.height / 2);
      }
      
      // Another heartbeat if we've progressed far enough
      if (progress > 0.7) {
        path.lineTo(size.width * 0.75, size.height * 0.3);
        path.lineTo(size.width * 0.8, size.height / 2);
        path.lineTo(size.width * 0.85, size.height * 0.1);
        path.lineTo(size.width * 0.9, size.height * 0.9);
        path.lineTo(size.width * 0.95, size.height / 2);
        path.lineTo(size.width, size.height / 2);
      }
    }
    
    // Clip the path to only show up to the current progress
    final clipPath = Path()
      ..moveTo(0, 0)
      ..lineTo(endX, 0)
      ..lineTo(endX, size.height)
      ..lineTo(0, size.height)
      ..close();
    
    canvas.clipPath(clipPath);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true; // Repaint when progress changes
  }
}

