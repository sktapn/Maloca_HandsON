import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:ui';
import 'package:image_picker/image_picker.dart';
import '../models/baby_data.dart';
import '../main.dart';

class BabyProfileScreen extends StatefulWidget {
  const BabyProfileScreen({super.key});

  @override
  State<BabyProfileScreen> createState() => _BabyProfileScreenState();
}

class _BabyProfileScreenState extends State<BabyProfileScreen> {
  final _nameController = TextEditingController();
  final _birthDateController = TextEditingController();
  final _notesController = TextEditingController();
  bool _isEditing = false;
  File? _imageFile;
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;
  
  // Referência ao singleton de dados do bebê
  final BabyData _babyData = BabyData();
  
  // Lista de tipos sanguíneos
  final List<String> _bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  
  // Lista de alergias comuns
  final List<String> _commonAllergies = [
    'Leite',
    'Ovo',
    'Amendoim',
    'Nozes',
    'Soja',
    'Trigo',
    'Peixe',
    'Frutos do mar',
    'Pólen',
    'Ácaros',
    'Pelo de animais',
    'Penicilina',
    'Látex'
  ];
  
  // Alergias selecionadas
  List<String> _selectedAllergies = [];
  String _bloodType = 'O+';

  @override
  void initState() {
    super.initState();
    _loadBabyData();
  }
  
  Future<void> _loadBabyData() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      // Carrega os dados do bebê do Supabase
      await _babyData.loadFromSupabase();
      
      // Inicializa os controladores com os dados atuais
      _nameController.text = _babyData.name;
      _birthDateController.text = _babyData.birthDate;
      _notesController.text = _babyData.observations;
      _bloodType = _babyData.bloodType;
      _selectedAllergies = List.from(_babyData.allergies);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erro ao carregar dados: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _birthDateController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  // Função para selecionar imagem da galeria ou câmera
  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(source: source);
      if (pickedFile != null) {
        setState(() {
          _imageFile = File(pickedFile.path);
        });
        // Adicionar feedback visual para o usuário
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Imagem selecionada com sucesso!'),
            backgroundColor: Color(0xFF4CAF50),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao selecionar imagem: $e')),
      );
    }
  }

  // Função para mostrar opções de seleção de imagem
  void _showImageSourceActionSheet() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: Icon(Icons.photo_library),
                title: Text('Galeria'),
                onTap: () {
                  Navigator.of(context).pop();
                  _pickImage(ImageSource.gallery);
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_camera),
                title: Text('Câmera'),
                onTap: () {
                  Navigator.of(context).pop();
                  _pickImage(ImageSource.camera);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  // Função para mostrar diálogo de seleção de alergias
  void _showAllergiesDialog() {
    // Crie uma cópia local das alergias selecionadas para manipulação no diálogo
    List<String> tempSelectedAllergies = List.from(_selectedAllergies);
    
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text('Selecione as Alergias'),
              content: Container(
                width: double.maxFinite,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: _commonAllergies.map((allergy) {
                      return CheckboxListTile(
                        title: Text(allergy),
                        value: tempSelectedAllergies.contains(allergy),
                        onChanged: (bool? value) {
                          setState(() {
                            if (value == true) {
                              tempSelectedAllergies.add(allergy);
                            } else {
                              tempSelectedAllergies.remove(allergy);
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () {
                    // Atualiza a lista principal com as seleções temporárias
                    this.setState(() {
                      _selectedAllergies.clear();
                      _selectedAllergies.addAll(tempSelectedAllergies);
                    });
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF0277BD),
                  ),
                  child: Text('Confirmar'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // Método para salvar todas as alterações
  Future<void> _saveChanges() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      String updatedImageUrl = _babyData.imageUrl;
      
      // Se houver uma nova imagem, faz o upload para o Supabase Storage
      if (_imageFile != null) {
        updatedImageUrl = await _babyData.uploadImage(_imageFile!.path);
      }
      
      // Atualiza o modelo de dados centralizado e salva no Supabase
      await _babyData.updateData(
        name: _nameController.text,
        birthDate: _birthDateController.text,
        bloodType: _bloodType,
        allergies: _selectedAllergies,
        observations: _notesController.text,
        imageUrl: updatedImageUrl,
      );
      
      setState(() {
        _isEditing = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Alterações salvas com sucesso!'),
          backgroundColor: Color(0xFF4CAF50),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erro ao salvar alterações: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        backgroundColor: Color(0xFFF5F7FA),
        appBar: AppBar(
          title: Text('Perfil do Bebê'),
        ),
        body: Center(
          child: CircularProgressIndicator(
            color: Color(0xFF0277BD),
          ),
        ),
      );
    }
    
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text('Perfil do Bebê'),
        actions: [
          // Botão de edição mais claro e com texto
          TextButton.icon(
            icon: Icon(
              _isEditing ? Icons.check : Icons.edit,
              color: Color(0xFF0277BD),
            ),
            label: Text(
              _isEditing ? 'Salvar' : 'Editar',
              style: TextStyle(
                color: Color(0xFF0277BD),
                fontWeight: FontWeight.bold,
              ),
            ),
            onPressed: () {
              if (_isEditing) {
                _saveChanges();
              } else {
                setState(() {
                  _isEditing = true;
                });
              }
            },
          ),
          SizedBox(width: 8),
        ],
      ),
      body: Stack(
        children: [
          // Medical pattern background
          Positioned.fill(
            child: CustomPaint(
              painter: MedicalPatternPainter(),
            ),
          ),
          
          // Top decoration
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: WavePainter(
                colors: [
                  Color(0xFF0277BD).withOpacity(0.15),
                  Color(0xFF00BCD4).withOpacity(0.15),
                ],
              ),
              size: Size(MediaQuery.of(context).size.width, 200),
            ),
          ),
          
          // Bottom decoration
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: BottomWavePainter(
                colors: [
                  Color(0xFF00BCD4).withOpacity(0.15),
                  Color(0xFF4CAF50).withOpacity(0.15),
                ],
              ),
              size: Size(MediaQuery.of(context).size.width, 200),
            ),
          ),
          
          SingleChildScrollView(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Adicionar indicador de modo de edição
                if (_isEditing)
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    margin: EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: Color(0xFF0277BD).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Color(0xFF0277BD).withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, color: Color(0xFF0277BD), size: 20),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Você está no modo de edição. Clique em "Salvar" quando terminar.',
                            style: TextStyle(
                              color: Color(0xFF0277BD),
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              
                // Baby profile header
                Center(
                  child: Column(
                    children: [
                      Stack(
                        children: [
                          CircleAvatar(
                            radius: 60,
                            backgroundColor: Colors.white,
                            backgroundImage: _imageFile != null 
                                ? FileImage(_imageFile!) as ImageProvider
                                : NetworkImage(_babyData.imageUrl),
                          ),
                          if (_isEditing)
                            Positioned(
                              right: 0,
                              bottom: 0,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF0277BD),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.white, width: 2),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 4,
                                      offset: Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    customBorder: CircleBorder(),
                                    onTap: _showImageSourceActionSheet,
                                    child: Padding(
                                      padding: EdgeInsets.all(8),
                                      child: Icon(
                                        Icons.camera_alt,
                                        color: Colors.white,
                                        size: 20,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                      SizedBox(height: 16),
                      _isEditing
                          ? Container(
                              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Color(0xFF0277BD).withOpacity(0.5)),
                              ),
                              child: TextField(
                                controller: _nameController,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF0277BD),
                                ),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintText: 'Nome do Bebê',
                                  contentPadding: EdgeInsets.zero,
                                ),
                                onChanged: (value) {
                                  // Atualiza o nome em tempo real
                                  setState(() {});
                                },
                              ),
                            )
                          : Text(
                              _nameController.text,
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF0277BD),
                              ),
                            ),
                      SizedBox(height: 8),
                      Text(
                        'Idade: 2 meses',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                
                SizedBox(height: 32),
                
                // Information section
                Text(
                  'Informações Básicas',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF333333),
                  ),
                ),
                
                SizedBox(height: 16),
                
                _buildDateField(
                  label: 'Data de Nascimento',
                  controller: _birthDateController,
                  icon: Icons.calendar_today,
                  isEditing: _isEditing,
                  onTap: _isEditing ? () => _selectDate(context) : null,
                ),
                
                _buildBloodTypeField(
                  label: 'Tipo Sanguíneo',
                  icon: Icons.bloodtype,
                  isEditing: _isEditing,
                ),
                
                _buildAllergiesField(
                  label: 'Alergias',
                  icon: Icons.warning_amber,
                  isEditing: _isEditing,
                ),
                
                SizedBox(height: 24),
                
                // Medical information
                Text(
                  'Informações Médicas',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF333333),
                  ),
                ),
                
                SizedBox(height: 16),
                
                // Medical cards
                _buildMedicalCard(
                  title: 'Pediatra',
                  value: 'Dra. Sarah Johnson',
                  icon: Icons.medical_services,
                  color: Color(0xFF0277BD),
                ),
                
                _buildMedicalCard(
                  title: 'Próxima Vacina',
                  value: 'Pentavalente - 15/03/2025',
                  icon: Icons.vaccines,
                  color: Color(0xFF00BCD4),
                ),
                
                _buildMedicalCard(
                  title: 'Plano de Saúde',
                  value: 'MediSaúde - Nº 123456789',
                  icon: Icons.health_and_safety,
                  color: Color(0xFF4CAF50),
                ),
                
                SizedBox(height: 24),
                
                // Notes section
                Text(
                  'Observações',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF333333),
                  ),
                ),
                
                SizedBox(height: 16),
                
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: _isEditing
                      ? TextField(
                          controller: _notesController,
                          maxLines: 5,
                          decoration: InputDecoration(
                            hintText: 'Adicione observações importantes sobre o bebê...',
                            border: InputBorder.none,
                          ),
                          onChanged: (value) {
                            // Garante que as alterações sejam aplicadas
                            setState(() {});
                          },
                        )
                      : Text(
                          _notesController.text.isEmpty
                              ? 'Nenhuma observação registrada.'
                              : _notesController.text,
                          style: TextStyle(
                            color: Colors.grey[700],
                            height: 1.5,
                          ),
                        ),
                ),
                
                SizedBox(height: 40),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: !_isEditing ? FloatingActionButton(
        backgroundColor: Color(0xFF0277BD),
        child: Icon(Icons.edit, color: Colors.white),
        onPressed: () {
          setState(() {
            _isEditing = true;
          });
        },
      ) : null,
    );
  }

  Widget _buildDateField({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    required bool isEditing,
    VoidCallback? onTap,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Color(0xFF0277BD).withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: Color(0xFF0277BD),
              size: 20,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 4),
                isEditing
                    ? GestureDetector(
                        onTap: onTap,
                        child: AbsorbPointer(
                          child: TextField(
                            controller: controller,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.zero,
                              suffixIcon: Icon(Icons.arrow_drop_down),
                            ),
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF333333),
                            ),
                          ),
                        ),
                      )
                    : Text(
                        controller.text,
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFF333333),
                        ),
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBloodTypeField({
    required String label,
    required IconData icon,
    required bool isEditing,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Color(0xFF0277BD).withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: Color(0xFF0277BD),
              size: 20,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 4),
                isEditing
                    ? Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Color(0xFF0277BD).withOpacity(0.5)),
                        ),
                        child: DropdownButton<String>(
                          value: _bloodType,
                          isExpanded: true,
                          underline: SizedBox(),
                          icon: Icon(Icons.arrow_drop_down, color: Color(0xFF0277BD)),
                          onChanged: (String? newValue) {
                            if (newValue != null) {
                              setState(() {
                                _bloodType = newValue;
                              });
                            }
                          },
                          items: _bloodTypes.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      )
                    : Text(
                        _bloodType,
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFF333333),
                        ),
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAllergiesField({
    required String label,
    required IconData icon,
    required bool isEditing,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Color(0xFF0277BD).withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: Color(0xFF0277BD),
              size: 20,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 4),
                isEditing
                    ? InkWell(
                        onTap: _showAllergiesDialog,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Color(0xFF0277BD).withOpacity(0.5)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  _selectedAllergies.isEmpty
                                      ? 'Toque para selecionar alergias'
                                      : _selectedAllergies.join(', '),
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: _selectedAllergies.isEmpty
                                        ? Colors.grey
                                        : Color(0xFF333333),
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Icon(Icons.arrow_drop_down, color: Color(0xFF0277BD)),
                            ],
                          ),
                        ),
                      )
                    : _selectedAllergies.isEmpty
                        ? Text(
                            'Nenhuma alergia registrada',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey,
                            ),
                          )
                        : Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _selectedAllergies.map((allergy) {
                              return Chip(
                                label: Text(
                                  allergy,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                  ),
                                ),
                                backgroundColor: Color(0xFF0277BD),
                              );
                            }).toList(),
                          ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMedicalCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xFF333333),
                  ),
                ),
              ],
            ),
          ),
          if (_isEditing)
            IconButton(
              icon: Icon(
                Icons.edit,
                color: Colors.grey[400],
                size: 20,
              ),
              onPressed: () {},
            ),
        ],
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: Color(0xFF0277BD),
            ),
          ),
          child: child!,
        );
      },
    );
    
    if (picked != null) {
      setState(() {
        _birthDateController.text = '${picked.day}/${picked.month}/${picked.year}';
      });
    }
  }
}

class MedicalPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF0277BD).withOpacity(0.1)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final spacing = 40.0;
    
    // Draw plus symbols pattern
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        // Horizontal line
        canvas.drawLine(
          Offset(x - 5, y),
          Offset(x + 5, y),
          paint,
        );
        
        // Vertical line
        canvas.drawLine(
          Offset(x, y - 5),
          Offset(x, y + 5),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class WavePainter extends CustomPainter {
  final List<Color> colors;

  WavePainter({required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: colors,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;
    
    final path = Path();
    
    path.moveTo(0, 0);
    path.lineTo(0, size.height * 0.5);
    
    // First wave
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height * 0.4,
      size.width * 0.5,
      size.height * 0.5,
    );
    
    // Second wave
    path.quadraticBezierTo(
      size.width * 0.75,
      size.height * 0.6,
      size.width,
      size.height * 0.5,
    );
    
    path.lineTo(size.width, 0);
    path.close();
    
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class BottomWavePainter extends CustomPainter {
  final List<Color> colors;

  BottomWavePainter({required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: colors,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;
    
    final path = Path();
    
    path.moveTo(0, size.height);
    path.lineTo(0, size.height * 0.5);
    
    // First wave
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height * 0.6,
      size.width * 0.5,
      size.height * 0.5,
    );
    
    // Second wave
    path.quadraticBezierTo(
      size.width * 0.75,
      size.height * 0.4,
      size.width,
      size.height * 0.5,
    );
    
    path.lineTo(size.width, size.height);
    path.close();
    
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

