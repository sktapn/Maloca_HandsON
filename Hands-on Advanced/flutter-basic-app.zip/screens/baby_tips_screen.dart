import 'package:flutter/material.dart';

class BabyTipsScreen extends StatefulWidget {
  const BabyTipsScreen({super.key});

  @override
  State<BabyTipsScreen> createState() => _BabyTipsScreenState();
}

class _BabyTipsScreenState extends State<BabyTipsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  final List<TipCategory> _categories = [
    TipCategory(
      title: 'Alimentação',
      icon: Icons.restaurant,
      color: Color(0xFFFF9800),
      tips: [
        Tip(
          title: 'Amamentação nos primeiros meses',
          content: 'A amamentação exclusiva é recomendada nos primeiros 6 meses de vida. O leite materno contém todos os nutrientes que o bebê precisa nessa fase, além de anticorpos que fortalecem o sistema imunológico.',
          imageUrl: 'https://randomuser.me/api/portraits/women/44.jpg',
        ),
        Tip(
          title: 'Introdução alimentar',
          content: 'A partir dos 6 meses, você pode começar a introduzir alimentos sólidos na dieta do bebê, mas continue amamentando. Comece com purês de frutas e legumes, um de cada vez, para identificar possíveis alergias.',
          imageUrl: 'https://randomuser.me/api/portraits/women/45.jpg',
        ),
      ],
    ),
    TipCategory(
      title: 'Sono',
      icon: Icons.nightlight_outlined,
      color: Color(0xFF9C27B0),
      tips: [
        Tip(
          title: 'Rotina de sono',
          content: 'Estabelecer uma rotina de sono ajuda o bebê a dormir melhor. Tente criar um ritual noturno consistente, como dar banho, trocar a fralda, amamentar e cantar uma canção de ninar.',
          imageUrl: 'https://randomuser.me/api/portraits/women/46.jpg',
        ),
        Tip(
          title: 'Ambiente seguro para dormir',
          content: 'O bebê deve dormir de barriga para cima em um colchão firme, sem travesseiros, cobertores soltos ou brinquedos no berço para reduzir o risco de sufocamento.',
          imageUrl: 'https://randomuser.me/api/portraits/women/47.jpg',
        ),
      ],
    ),
    TipCategory(
      title: 'Higiene',
      icon: Icons.clean_hands,
      color: Color(0xFF4CAF50),
      tips: [
        Tip(
          title: 'Banho do bebê',
          content: 'O banho do recém-nascido deve ser rápido e em água morna (37°C). Não é necessário dar banho todos os dias nas primeiras semanas. Use sabonetes neutros específicos para bebês.',
          imageUrl: 'https://randomuser.me/api/portraits/women/48.jpg',
        ),
        Tip(
          title: 'Cuidados com o umbigo',
          content: 'Mantenha o coto umbilical limpo e seco. Limpe ao redor da base com álcool 70% após o banho e troca de fraldas até que caia naturalmente (geralmente entre 7 e 14 dias).',
          imageUrl: 'https://randomuser.me/api/portraits/women/49.jpg',
        ),
      ],
    ),
    TipCategory(
      title: 'Desenvolvimento',
      icon: Icons.child_care,
      color: Color(0xFF0277BD),
      tips: [
        Tip(
          title: 'Estímulos importantes',
          content: 'Converse com seu bebê, cante, leia histórias e faça contato visual. Esses estímulos são fundamentais para o desenvolvimento cognitivo e da linguagem.',
          imageUrl: 'https://randomuser.me/api/portraits/women/50.jpg',
        ),
        Tip(
          title: 'Tempo de barriga para baixo',
          content: 'Quando o bebê estiver acordado e supervisionado, coloque-o de barriga para baixo por alguns minutos várias vezes ao dia. Isso fortalece os músculos do pescoço e das costas.',
          imageUrl: 'https://randomuser.me/api/portraits/women/51.jpg',
        ),
      ],
    ),
    TipCategory(
      title: 'Saúde',
      icon: Icons.health_and_safety,
      color: Color(0xFF3F51B5),
      tips: [
        Tip(
          title: 'Vacinação',
          content: 'Siga rigorosamente o calendário de vacinação. As vacinas são essenciais para proteger seu bebê contra doenças graves.',
          imageUrl: 'https://randomuser.me/api/portraits/women/52.jpg',
        ),
        Tip(
          title: 'Quando procurar o médico',
          content: 'Procure atendimento médico imediato se o bebê apresentar febre acima de 38°C, dificuldade para respirar, recusa alimentar persistente, vômitos frequentes ou letargia.',
          imageUrl: 'https://randomuser.me/api/portraits/women/53.jpg',
        ),
      ],
    ),
  ];
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text('Dicas e Educação'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: Color(0xFF0277BD),
          unselectedLabelColor: Colors.grey,
          indicatorColor: Color(0xFF0277BD),
          tabs: _categories.map((category) {
            return Tab(
              text: category.title,
              icon: Icon(category.icon),
            );
          }).toList(),
        ),
      ),
      body: Stack(
        children: [
          // Medical pattern background
          Positioned.fill(
            child: CustomPaint(
              painter: MedicalPatternPainter(),
            ),
          ),
          
          TabBarView(
            controller: _tabController,
            children: _categories.map((category) {
              return _buildCategoryContent(category);
            }).toList(),
          ),
        ],
      ),
    );
  }
  
  Widget _buildCategoryContent(TipCategory category) {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: category.tips.length,
      itemBuilder: (context, index) {
        final tip = category.tips[index];
        return _buildTipCard(tip, category.color);
      },
    );
  }
  
  Widget _buildTipCard(Tip tip, Color color) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Tip header with image
          ClipRRect(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16),
              topRight: Radius.circular(16),
            ),
            child: Image.network(
              tip.imageUrl,
              height: 180,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          
          // Tip title
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              border: Border(
                bottom: BorderSide(
                  color: color.withOpacity(0.2),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.lightbulb_outline,
                    color: color,
                    size: 20,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    tip.title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      color: Color(0xFF333333),
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // Tip content
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              tip.content,
              style: TextStyle(
                fontSize: 16,
                color: Color(0xFF666666),
                height: 1.5,
              ),
            ),
          ),
          
          // Tip actions
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () {},
                  icon: Icon(
                    Icons.bookmark_border,
                    size: 18,
                    color: color,
                  ),
                  label: Text('Salvar'),
                  style: TextButton.styleFrom(
                    foregroundColor: color,
                  ),
                ),
                SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () {},
                  icon: Icon(
                    Icons.share,
                    size: 18,
                    color: Colors.grey[600],
                  ),
                  label: Text('Compartilhar'),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TipCategory {
  final String title;
  final IconData icon;
  final Color color;
  final List<Tip> tips;
  
  TipCategory({
    required this.title,
    required this.icon,
    required this.color,
    required this.tips,
  });
}

class Tip {
  final String title;
  final String content;
  final String imageUrl;
  
  Tip({
    required this.title,
    required this.content,
    required this.imageUrl,
  });
}

class MedicalPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF0277BD).withOpacity(0.1)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final spacing = 40.0;
    
    // Draw plus symbols pattern
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        // Horizontal line
        canvas.drawLine(
          Offset(x - 5, y),
          Offset(x + 5, y),
          paint,
        );
        
        // Vertical line
        canvas.drawLine(
          Offset(x, y - 5),
          Offset(x, y + 5),
          paint,
        );
      }
    }
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

