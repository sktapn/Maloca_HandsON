import 'package:flutter/material.dart';
import '../models/appointment.dart';

class AppointmentsHistoryScreen extends StatefulWidget {
  const AppointmentsHistoryScreen({super.key});

  @override
  State<AppointmentsHistoryScreen> createState() => _AppointmentsHistoryScreenState();
}

class _AppointmentsHistoryScreenState extends State<AppointmentsHistoryScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Appointment> _upcomingAppointments = [];
  List<Appointment> _pastAppointments = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadAppointments();
  }

  Future<void> _loadAppointments() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // In a real app, you would fetch from Supabase
      await Future.delayed(const Duration(seconds: 1));
      
      setState(() {
        _upcomingAppointments = [
          Appointment(
            id: '1',
            doctorName: 'Dr. Sarah Johnson',
            doctorSpecialty: 'Cardiologist',
            doctorImage: 'https://randomuser.me/api/portraits/women/44.jpg',
            date: DateTime.now().add(const Duration(days: 2)),
            time: '10:00 AM',
            reason: 'Annual heart checkup',
            status: AppointmentStatus.confirmed,
          ),
          Appointment(
            id: '2',
            doctorName: 'Dr. Michael Chen',
            doctorSpecialty: 'Neurologist',
            doctorImage: 'https://randomuser.me/api/portraits/men/32.jpg',
            date: DateTime.now().add(const Duration(days: 5)),
            time: '02:30 PM',
            reason: 'Headache consultation',
            status: AppointmentStatus.pending,
          ),
        ];
        
        _pastAppointments = [
          Appointment(
            id: '3',
            doctorName: 'Dr. Emily Rodriguez',
            doctorSpecialty: 'Pediatrician',
            doctorImage: 'https://randomuser.me/api/portraits/women/68.jpg',
            date: DateTime.now().subtract(const Duration(days: 10)),
            time: '09:15 AM',
            reason: 'Flu symptoms',
            status: AppointmentStatus.completed,
          ),
          Appointment(
            id: '4',
            doctorName: 'Dr. James Wilson',
            doctorSpecialty: 'Dermatologist',
            doctorImage: 'https://randomuser.me/api/portraits/men/52.jpg',
            date: DateTime.now().subtract(const Duration(days: 30)),
            time: '11:00 AM',
            reason: 'Skin rash examination',
            status: AppointmentStatus.completed,
          ),
        ];
      });
    } catch (error) {
      // Handle error
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Appointments'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Upcoming'),
            Tab(text: 'Past'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                // Upcoming appointments tab
                _buildAppointmentsList(_upcomingAppointments),
                
                // Past appointments tab
                _buildAppointmentsList(_pastAppointments),
              ],
            ),
    );
  }

  Widget _buildAppointmentsList(List<Appointment> appointments) {
    if (appointments.isEmpty) {
      return const Center(
        child: Text(
          'No appointments found',
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadAppointments,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: appointments.length,
        itemBuilder: (context, index) {
          final appointment = appointments[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 24,
                        backgroundImage: NetworkImage(appointment.doctorImage),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              appointment.doctorName,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Text(
                              appointment.doctorSpecialty,
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                      _buildStatusChip(appointment.status),
                    ],
                  ),
                  const Divider(height: 24),
                  _buildInfoRow(Icons.calendar_today, 'Date', 
                      '${appointment.date.day}/${appointment.date.month}/${appointment.date.year}'),
                  const SizedBox(height: 8),
                  _buildInfoRow(Icons.access_time, 'Time', appointment.time),
                  const SizedBox(height: 8),
                  _buildInfoRow(Icons.medical_services, 'Reason', appointment.reason),
                  
                  if (appointment.status == AppointmentStatus.confirmed ||
                      appointment.status == AppointmentStatus.pending)
                    Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          OutlinedButton(
                            onPressed: () {
                              // Cancel appointment logic
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.red,
                            ),
                            child: const Text('Cancel'),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: () {
                              // Reschedule appointment logic
                            },
                            child: const Text('Reschedule'),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Colors.grey[600]),
        const SizedBox(width: 8),
        Text(
          '$label: ',
          style: TextStyle(
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatusChip(AppointmentStatus status) {
    Color color;
    String text;
    
    switch (status) {
      case AppointmentStatus.confirmed:
        color = Colors.green;
        text = 'Confirmed';
        break;
      case AppointmentStatus.pending:
        color = Colors.orange;
        text = 'Pending';
        break;
      case AppointmentStatus.completed:
        color = Colors.blue;
        text = 'Completed';
        break;
      case AppointmentStatus.cancelled:
        color = Colors.red;
        text = 'Cancelled';
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

