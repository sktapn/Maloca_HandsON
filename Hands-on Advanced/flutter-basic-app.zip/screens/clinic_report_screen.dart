import 'package:flutter/material.dart';

class ClinicReportScreen extends StatefulWidget {
  const ClinicReportScreen({super.key});

  @override
  State<ClinicReportScreen> createState() => _ClinicReportScreenState();
}

class _ClinicReportScreenState extends State<ClinicReportScreen> {
  final List<Report> _reports = [
    Report(
      id: '1',
      title: 'Relatório de Desenvolvimento',
      date: '15/02/2025',
      doctorName: 'Dr. Michael Chen',
      content: 'O bebê apresenta desenvolvimento normal para a idade. Peso e altura dentro dos padrões esperados. Reflexos normais. Recomenda-se continuar com aleitamento materno exclusivo.',
      metrics: {
        'Peso': '3.6 kg',
        'Altura': '51 cm',
        'Perímetro Cefálico': '36 cm',
      },
    ),
    Report(
      id: '2',
      title: 'Relatório de Nascimento',
      date: '15/01/2025',
      doctorName: 'Dra. Emily Rodriguez',
      content: 'Recém-nascido saudável, sem complicações durante o parto. Apgar 9/10. Todos os reflexos neonatais presentes. Iniciou amamentação sem dificuldades.',
      metrics: {
        'Peso ao Nascer': '3.2 kg',
        'Altura': '49 cm',
        'Perímetro Cefálico': '34 cm',
        'Apgar': '9/10',
      },
    ),
  ];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text('Relatórios Médicos'),
      ),
      body: Stack(
        children: [
          // Medical pattern background
          Positioned.fill(
            child: CustomPaint(
              painter: MedicalPatternPainter(),
            ),
          ),
          
          // Top decoration
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: WavePainter(
                colors: [
                  Color(0xFF0277BD).withOpacity(0.15),
                  Color(0xFF00BCD4).withOpacity(0.15),
                ],
              ),
              size: Size(MediaQuery.of(context).size.width, 200),
            ),
          ),
          
          // Content
          ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: _reports.length,
            itemBuilder: (context, index) {
              final report = _reports[index];
              return _buildReportCard(report);
            },
          ),
        ],
      ),
    );
  }
  
  Widget _buildReportCard(Report report) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Report header
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Color(0xFF0277BD).withOpacity(0.1),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.description,
                    color: Color(0xFF0277BD),
                    size: 20,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        report.title,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Color(0xFF333333),
                        ),
                      ),
                      Text(
                        'Dr. ${report.doctorName} • ${report.date}',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Report content
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Avaliação Médica:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Color(0xFF333333),
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  report.content,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[700],
                    height: 1.5,
                  ),
                ),
                
                SizedBox(height: 16),
                
                Text(
                  'Métricas:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Color(0xFF333333),
                  ),
                ),
                SizedBox(height: 8),
                
                // Metrics grid
                GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 2.5,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: report.metrics.length,
                  itemBuilder: (context, index) {
                    final metric = report.metrics.entries.elementAt(index);
                    return Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Color(0xFFF5F7FA),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            metric.key,
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 12,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            metric.value,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Color(0xFF333333),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          
          // Report actions
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () {},
                  icon: Icon(
                    Icons.print,
                    size: 18,
                    color: Colors.grey[600],
                  ),
                  label: Text('Imprimir'),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.grey[600],
                  ),
                ),
                SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () {},
                  icon: Icon(
                    Icons.share,
                    size: 18,
                    color: Color(0xFF0277BD),
                  ),
                  label: Text('Compartilhar'),
                  style: TextButton.styleFrom(
                    foregroundColor: Color(0xFF0277BD),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Report {
  final String id;
  final String title;
  final String date;
  final String doctorName;
  final String content;
  final Map<String, String> metrics;
  
  Report({
    required this.id,
    required this.title,
    required this.date,
    required this.doctorName,
    required this.content,
    required this.metrics,
  });
}

class MedicalPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF0277BD).withOpacity(0.1)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final spacing = 40.0;
    
    // Draw plus symbols pattern
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        // Horizontal line
        canvas.drawLine(
          Offset(x - 5, y),
          Offset(x + 5, y),
          paint,
        );
        
        // Vertical line
        canvas.drawLine(
          Offset(x, y - 5),
          Offset(x, y + 5),
          paint,
        );
      }
    }
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class WavePainter extends CustomPainter {
  final List<Color> colors;
  
  WavePainter({required this.colors});
  
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: colors,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;
    
    final path = Path();
    
    path.moveTo(0, 0);
    path.lineTo(0, size.height * 0.5);
    
    // First wave
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height * 0.4,
      size.width * 0.5,
      size.height * 0.5,
    );
    
    // Second wave
    path.quadraticBezierTo(
      size.width * 0.75,
      size.height * 0.6,
      size.width,
      size.height * 0.5,
    );
    
    path.lineTo(size.width, 0);
    path.close();
    
    canvas.drawPath(path, paint);
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

