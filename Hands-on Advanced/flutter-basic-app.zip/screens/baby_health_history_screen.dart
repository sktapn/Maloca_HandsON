import 'package:flutter/material.dart';

class BabyHealthHistoryScreen extends StatefulWidget {
  const BabyHealthHistoryScreen({super.key});

  @override
  State<BabyHealthHistoryScreen> createState() => _BabyHealthHistoryScreenState();
}

class _BabyHealthHistoryScreenState extends State<BabyHealthHistoryScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text('Histórico de Saúde'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Color(0xFF0277BD),
          unselectedLabelColor: Colors.grey,
          indicatorColor: Color(0xFF0277BD),
          tabs: [
            Tab(text: 'Crescimento'),
            Tab(text: 'Vacinas'),
            Tab(text: 'Consultas'),
          ],
        ),
      ),
      body: Stack(
        children: [
          // Medical pattern background
          Positioned.fill(
            child: CustomPaint(
              painter: MedicalPatternPainter(),
            ),
          ),
          
          TabBarView(
            controller: _tabController,
            children: [
              // Growth tab
              _buildGrowthTab(),
              
              // Vaccines tab
              _buildVaccinesTab(),
              
              // Appointments tab
              _buildAppointmentsTab(),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildGrowthTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Curva de Crescimento'),
          SizedBox(height: 16),
          
          // Growth chart placeholder
          Container(
            height: 200,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Center(
              child: Text(
                'Gráfico de crescimento em desenvolvimento',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 14,
                ),
              ),
            ),
          ),
          
          SizedBox(height: 24),
          _buildSectionTitle('Histórico de Medições'),
          SizedBox(height: 16),
          
          // Measurements history
          _buildMeasurementCard(
            date: '15/02/2025',
            age: '1 mês',
            weight: '3.6 kg',
            height: '51 cm',
            headCircumference: '36 cm',
          ),
          
          _buildMeasurementCard(
            date: '15/01/2025',
            age: 'Nascimento',
            weight: '3.2 kg',
            height: '49 cm',
            headCircumference: '34 cm',
          ),
          
          SizedBox(height: 24),
          _buildSectionTitle('Marcos de Desenvolvimento'),
          SizedBox(height: 16),
          
          // Development milestones
          _buildMilestoneCard(
            milestone: 'Sorrir socialmente',
            expectedAge: '1-2 meses',
            achievedAge: '1 mês e 5 dias',
            date: '20/02/2025',
            isAchieved: true,
          ),
          
          _buildMilestoneCard(
            milestone: 'Segurar a cabeça',
            expectedAge: '2-4 meses',
            achievedAge: '',
            date: '',
            isAchieved: false,
          ),
          
          _buildMilestoneCard(
            milestone: 'Rolar',
            expectedAge: '4-6 meses',
            achievedAge: '',
            date: '',
            isAchieved: false,
          ),
          
          SizedBox(height: 40),
        ],
      ),
    );
  }
  
  Widget _buildVaccinesTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Calendário de Vacinação'),
          SizedBox(height: 16),
          
          // Vaccines list
          _buildVaccineCard(
            name: 'BCG',
            recommendedAge: 'Ao nascer',
            date: '15/01/2025',
            isApplied: true,
            nextDose: null,
          ),
          
          _buildVaccineCard(
            name: 'Hepatite B',
            recommendedAge: 'Ao nascer',
            date: '15/01/2025',
            isApplied: true,
            nextDose: '15/03/2025 (2ª dose)',
          ),
          
          _buildVaccineCard(
            name: 'Pentavalente',
            recommendedAge: '2 meses',
            date: '',
            isApplied: false,
            nextDose: '15/03/2025 (1ª dose)',
          ),
          
          _buildVaccineCard(
            name: 'VIP/VOP (Poliomielite)',
            recommendedAge: '2 meses',
            date: '',
            isApplied: false,
            nextDose: '15/03/2025 (1ª dose)',
          ),
          
          _buildVaccineCard(
            name: 'Pneumocócica 10V',
            recommendedAge: '2 meses',
            date: '',
            isApplied: false,
            nextDose: '15/03/2025 (1ª dose)',
          ),
          
          _buildVaccineCard(
            name: 'Rotavírus',
            recommendedAge: '2 meses',
            date: '',
            isApplied: false,
            nextDose: '15/03/2025 (1ª dose)',
          ),
          
          SizedBox(height: 40),
        ],
      ),
    );
  }
  
  Widget _buildAppointmentsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Histórico de Consultas'),
          SizedBox(height: 16),
          
          // Appointments history
          _buildAppointmentHistoryCard(
            doctorName: 'Dr. Michael Chen',
            specialty: 'Pediatra',
            date: '15/02/2025',
            reason: 'Consulta de rotina - 1 mês',
            notes: 'Bebê apresentou bom desenvolvimento. Peso: 3.6kg, Altura: 51cm.',
          ),
          
          _buildAppointmentHistoryCard(
            doctorName: 'Dra. Emily Rodriguez',
            specialty: 'Pediatra',
            date: '15/01/2025',
            reason: 'Primeira consulta após nascimento',
            notes: 'Primeira consulta após nascimento. Bebê saudável. Peso: 3.2kg, Altura: 49cm.',
          ),
          
          SizedBox(height: 24),
          _buildSectionTitle('Próximas Consultas'),
          SizedBox(height: 16),
          
          // Upcoming appointments
          _buildUpcomingAppointmentCard(
            doctorName: 'Dra. Sarah Johnson',
            specialty: 'Pediatra',
            date: '15/03/2025',
            time: '10:30',
            reason: 'Consulta de rotina - 2 meses',
          ),
          
          SizedBox(height: 40),
        ],
      ),
    );
  }
  
  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Color(0xFF333333),
      ),
    );
  }
  
  Widget _buildMeasurementCard({
    required String date,
    required String age,
    required String weight,
    required String height,
    required String headCircumference,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                date,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: Color(0xFF333333),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Color(0xFF0277BD).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  age,
                  style: TextStyle(
                    color: Color(0xFF0277BD),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildMeasurementItem(
                  icon: Icons.monitor_weight_outlined,
                  label: 'Peso',
                  value: weight,
                  color: Color(0xFF0277BD),
                ),
              ),
              Expanded(
                child: _buildMeasurementItem(
                  icon: Icons.height,
                  label: 'Altura',
                  value: height,
                  color: Color(0xFF00BCD4),
                ),
              ),
              Expanded(
                child: _buildMeasurementItem(
                  icon: Icons.face,
                  label: 'PC',
                  value: headCircumference,
                  color: Color(0xFF4CAF50),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildMeasurementItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(
          icon,
          color: color,
          size: 20,
        ),
        SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 12,
          ),
        ),
        SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: Color(0xFF333333),
          ),
        ),
      ],
    );
  }
  
  Widget _buildMilestoneCard({
    required String milestone,
    required String expectedAge,
    required String achievedAge,
    required String date,
    required bool isAchieved,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isAchieved ? Color(0xFF4CAF50).withOpacity(0.1) : Colors.grey[200],
              shape: BoxShape.circle,
            ),
            child: Icon(
              isAchieved ? Icons.check : Icons.hourglass_empty,
              color: isAchieved ? Color(0xFF4CAF50) : Colors.grey,
              size: 20,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  milestone,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Color(0xFF333333),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Esperado: $expectedAge',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
                if (isAchieved) ...[
                  SizedBox(height: 4),
                  Text(
                    'Alcançado: $achievedAge ($date)',
                    style: TextStyle(
                      color: Color(0xFF4CAF50),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildVaccineCard({
    required String name,
    required String recommendedAge,
    required String date,
    required bool isApplied,
    required String? nextDose,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isApplied ? Color(0xFF4CAF50).withOpacity(0.1) : Color(0xFF0277BD).withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              isApplied ? Icons.check : Icons.event,
              color: isApplied ? Color(0xFF4CAF50) : Color(0xFF0277BD),
              size: 20,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Color(0xFF333333),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Recomendado: $recommendedAge',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
                if (isApplied) ...[
                  SizedBox(height: 4),
                  Text(
                    'Aplicada em: $date',
                    style: TextStyle(
                      color: Color(0xFF4CAF50),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
                if (nextDose != null) ...[
                  SizedBox(height: 4),
                  Text(
                    'Próxima dose: $nextDose',
                    style: TextStyle(
                      color: Color(0xFF0277BD),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildAppointmentHistoryCard({
    required String doctorName,
    required String specialty,
    required String date,
    required String reason,
    required String notes,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Color(0xFF4CAF50).withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.check_circle,
                  color: Color(0xFF4CAF50),
                  size: 20,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      doctorName,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        color: Color(0xFF333333),
                      ),
                    ),
                    Text(
                      '$specialty • $date',
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Text(
            'Motivo: $reason',
            style: TextStyle(
              fontSize: 13,
              color: Color(0xFF333333),
            ),
          ),
          SizedBox(height: 4),
          Text(
            'Observações: $notes',
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey[700],
            ),
          ),
          SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () {},
              style: TextButton.styleFrom(
                foregroundColor: Color(0xFF0277BD),
                padding: EdgeInsets.zero,
                minimumSize: Size(0, 0),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              child: Text('Ver detalhes'),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildUpcomingAppointmentCard({
    required String doctorName,
    required String specialty,
    required String date,
    required String time,
    required String reason,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Color(0xFF0277BD).withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.event,
                  color: Color(0xFF0277BD),
                  size: 20,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      doctorName,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        color: Color(0xFF333333),
                      ),
                    ),
                    Text(
                      '$specialty • $date, $time',
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Color(0xFF0277BD).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Color(0xFF0277BD),
                    width: 1,
                  ),
                ),
                child: Text(
                  'Agendada',
                  style: TextStyle(
                    color: Color(0xFF0277BD),
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Text(
            'Motivo: $reason',
            style: TextStyle(
              fontSize: 13,
              color: Color(0xFF333333),
            ),
          ),
          SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              OutlinedButton(
                onPressed: () {},
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.red,
                  side: BorderSide(color: Colors.red),
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  minimumSize: Size(0, 0),
                ),
                child: Text('Cancelar'),
              ),
              SizedBox(width: 8),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF0277BD),
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  minimumSize: Size(0, 0),
                ),
                child: Text('Reagendar'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class MedicalPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF0277BD).withOpacity(0.1)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final spacing = 40.0;
    
    // Draw plus symbols pattern
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        // Horizontal line
        canvas.drawLine(
          Offset(x - 5, y),
          Offset(x + 5, y),
          paint,
        );
        
        // Vertical line
        canvas.drawLine(
          Offset(x, y - 5),
          Offset(x, y + 5),
          paint,
        );
      }
    }
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

