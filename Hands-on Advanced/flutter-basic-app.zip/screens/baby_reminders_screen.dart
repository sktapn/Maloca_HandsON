import 'package:flutter/material.dart';

class BabyRemindersScreen extends StatefulWidget {
  const BabyRemindersScreen({super.key});

  @override
  State<BabyRemindersScreen> createState() => _BabyRemindersScreenState();
}

class _BabyRemindersScreenState extends State<BabyRemindersScreen> {
  final List<Reminder> _reminders = [
    Reminder(
      id: '1',
      title: 'Consulta Pediátrica',
      date: DateTime(2025, 3, 15, 10, 30),
      description: 'Consulta de rotina com Dra. Sarah Johnson',
      isCompleted: false,
      category: ReminderCategory.medical,
    ),
    Reminder(
      id: '2',
      title: 'Vacina Pentavalente',
      date: DateTime(2025, 3, 15, 10, 30),
      description: 'Primeira dose da vacina pentavalente',
      isCompleted: false,
      category: ReminderCategory.vaccine,
    ),
    Reminder(
      id: '3',
      title: 'Trocar Fraldas',
      date: DateTime(2025, 2, 25, 14, 0),
      description: 'Lembrete para trocar as fraldas',
      isCompleted: true,
      category: ReminderCategory.care,
      repeatInterval: RepeatInterval.threeHours,
    ),
    Reminder(
      id: '4',
      title: 'Dar Medicamento',
      date: DateTime(2025, 2, 25, 8, 0),
      description: 'Vitamina D - 1 gota',
      isCompleted: true,
      category: ReminderCategory.medication,
      repeatInterval: RepeatInterval.daily,
    ),
  ];

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  ReminderCategory _selectedCategory = ReminderCategory.care;
  RepeatInterval? _selectedRepeatInterval;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _showAddReminderDialog() {
    _titleController.clear();
    _descriptionController.clear();
    _selectedDate = DateTime.now();
    _selectedCategory = ReminderCategory.care;
    _selectedRepeatInterval = null;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text('Novo Lembrete'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: _titleController,
                      decoration: InputDecoration(
                        labelText: 'Título',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      controller: _descriptionController,
                      decoration: InputDecoration(
                        labelText: 'Descrição',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 2,
                    ),
                    SizedBox(height: 16),
                    Text('Data e Hora:'),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(
                        '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year} às ${_selectedDate.hour}:${_selectedDate.minute.toString().padLeft(2, '0')}',
                        style: TextStyle(fontSize: 16),
                      ),
                      trailing: Icon(Icons.calendar_today),
                      onTap: () async {
                        final date = await showDatePicker(
                          context: context,
                          initialDate: _selectedDate,
                          firstDate: DateTime.now(),
                          lastDate: DateTime(2030),
                        );
                        if (date != null) {
                          final time = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.fromDateTime(_selectedDate),
                          );
                          if (time != null) {
                            setState(() {
                              _selectedDate = DateTime(
                                date.year,
                                date.month,
                                date.day,
                                time.hour,
                                time.minute,
                              );
                            });
                          }
                        }
                      },
                    ),
                    SizedBox(height: 16),
                    Text('Categoria:'),
                    DropdownButton<ReminderCategory>(
                      isExpanded: true,
                      value: _selectedCategory,
                      items: ReminderCategory.values.map((category) {
                        return DropdownMenuItem<ReminderCategory>(
                          value: category,
                          child: Text(_getCategoryName(category)),
                        );
                      }).toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setState(() {
                            _selectedCategory = value;
                          });
                        }
                      },
                    ),
                    SizedBox(height: 16),
                    Text('Repetir:'),
                    DropdownButton<RepeatInterval?>(
                      isExpanded: true,
                      value: _selectedRepeatInterval,
                      items: [
                        DropdownMenuItem<RepeatInterval?>(
                          value: null,
                          child: Text('Não repetir'),
                        ),
                        ...RepeatInterval.values.map((interval) {
                          return DropdownMenuItem<RepeatInterval?>(
                            value: interval,
                            child: Text(_getRepeatIntervalName(interval)),
                          );
                        }).toList(),
                      ],
                      onChanged: (value) {
                        setState(() {
                          _selectedRepeatInterval = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_titleController.text.isNotEmpty) {
                      final newReminder = Reminder(
                        id: DateTime.now().millisecondsSinceEpoch.toString(),
                        title: _titleController.text,
                        date: _selectedDate,
                        description: _descriptionController.text,
                        isCompleted: false,
                        category: _selectedCategory,
                        repeatInterval: _selectedRepeatInterval,
                      );
                      
                      setState(() {
                        this._reminders.add(newReminder);
                      });
                      
                      Navigator.pop(context);
                      
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Lembrete adicionado com sucesso!'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF0277BD),
                  ),
                  child: Text('Adicionar'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  String _getCategoryName(ReminderCategory category) {
    switch (category) {
      case ReminderCategory.care:
        return 'Cuidados';
      case ReminderCategory.medical:
        return 'Consulta Médica';
      case ReminderCategory.medication:
        return 'Medicamento';
      case ReminderCategory.vaccine:
        return 'Vacina';
      case ReminderCategory.other:
        return 'Outro';
    }
  }

  String _getRepeatIntervalName(RepeatInterval interval) {
    switch (interval) {
      case RepeatInterval.threeHours:
        return 'A cada 3 horas';
      case RepeatInterval.daily:
        return 'Diariamente';
      case RepeatInterval.weekly:
        return 'Semanalmente';
      case RepeatInterval.monthly:
        return 'Mensalmente';
    }
  }

  Color _getCategoryColor(ReminderCategory category) {
    switch (category) {
      case ReminderCategory.care:
        return Color(0xFF4CAF50);
      case ReminderCategory.medical:
        return Color(0xFF0277BD);
      case ReminderCategory.medication:
        return Color(0xFFFF9800);
      case ReminderCategory.vaccine:
        return Color(0xFF9C27B0);
      case ReminderCategory.other:
        return Color(0xFF607D8B);
    }
  }

  IconData _getCategoryIcon(ReminderCategory category) {
    switch (category) {
      case ReminderCategory.care:
        return Icons.baby_changing_station;
      case ReminderCategory.medical:
        return Icons.medical_services;
      case ReminderCategory.medication:
        return Icons.medication;
      case ReminderCategory.vaccine:
        return Icons.vaccines;
      case ReminderCategory.other:
        return Icons.more_horiz;
    }
  }

  @override
  Widget build(BuildContext context) {
    // Separar lembretes em ativos e concluídos
    final activeReminders = _reminders.where((r) => !r.isCompleted).toList();
    final completedReminders = _reminders.where((r) => r.isCompleted).toList();

    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text('Lembretes'),
      ),
      body: Stack(
        children: [
          // Medical pattern background
          Positioned.fill(
            child: CustomPaint(
              painter: MedicalPatternPainter(),
            ),
          ),
          
          // Top decoration
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: WavePainter(
                colors: [
                  Color(0xFF0277BD).withOpacity(0.15),
                  Color(0xFF00BCD4).withOpacity(0.15),
                ],
              ),
              size: Size(MediaQuery.of(context).size.width, 200),
            ),
          ),
          
          // Content
          ListView(
            padding: EdgeInsets.all(16),
            children: [
              // Próximos lembretes
              Text(
                'Próximos Lembretes',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF333333),
                ),
              ),
              SizedBox(height: 16),
              
              if (activeReminders.isEmpty)
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Nenhum lembrete ativo',
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 14,
                      ),
                    ),
                  ),
                )
              else
                ...activeReminders.map((reminder) => _buildReminderCard(reminder)),
              
              SizedBox(height: 24),
              
              // Lembretes concluídos
              Text(
                'Concluídos',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF333333),
                ),
              ),
              SizedBox(height: 16),
              
              if (completedReminders.isEmpty)
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Nenhum lembrete concluído',
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 14,
                      ),
                    ),
                  ),
                )
              else
                ...completedReminders.map((reminder) => _buildReminderCard(reminder)),
              
              SizedBox(height: 80), // Espaço para o FAB
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFF0277BD),
        child: Icon(Icons.add, color: Colors.white),
        onPressed: _showAddReminderDialog,
      ),
    );
  }

  Widget _buildReminderCard(Reminder reminder) {
    final color = _getCategoryColor(reminder.category);
    final icon = _getCategoryIcon(reminder.category);
    
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Reminder header
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    icon,
                    color: color,
                    size: 20,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        reminder.title,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Color(0xFF333333),
                        ),
                      ),
                      Text(
                        _getCategoryName(reminder.category),
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                Checkbox(
                  value: reminder.isCompleted,
                  activeColor: color,
                  onChanged: (value) {
                    setState(() {
                      reminder.isCompleted = value ?? false;
                    });
                  },
                ),
              ],
            ),
          ),
          
          // Reminder details
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      color: Colors.grey[600],
                      size: 16,
                    ),
                    SizedBox(width: 8),
                    Text(
                      '${reminder.date.day}/${reminder.date.month}/${reminder.date.year} às ${reminder.date.hour}:${reminder.date.minute.toString().padLeft(2, '0')}',
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xFF333333),
                      ),
                    ),
                  ],
                ),
                
                if (reminder.repeatInterval != null) ...[
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(
                        Icons.repeat,
                        color: Colors.grey[600],
                        size: 16,
                      ),
                      SizedBox(width: 8),
                      Text(
                        _getRepeatIntervalName(reminder.repeatInterval!),
                        style: TextStyle(
                          fontSize: 14,
                          color: Color(0xFF333333),
                        ),
                      ),
                    ],
                  ),
                ],
                
                if (reminder.description.isNotEmpty) ...[
                  SizedBox(height: 12),
                  Text(
                    reminder.description,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[700],
                    ),
                  ),
                ],
              ],
            ),
          ),
          
          // Reminder actions
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () {
                    // Editar lembrete
                  },
                  icon: Icon(
                    Icons.edit,
                    size: 18,
                    color: Colors.grey[600],
                  ),
                  label: Text('Editar'),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.grey[600],
                  ),
                ),
                SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () {
                    setState(() {
                      _reminders.remove(reminder);
                    });
                    
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Lembrete removido'),
                        backgroundColor: Colors.red,
                        action: SnackBarAction(
                          label: 'DESFAZER',
                          textColor: Colors.white,
                          onPressed: () {
                            setState(() {
                              _reminders.add(reminder);
                            });
                          },
                        ),
                      ),
                    );
                  },
                  icon: Icon(
                    Icons.delete,
                    size: 18,
                    color: Colors.red,
                  ),
                  label: Text('Excluir'),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.red,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

enum ReminderCategory {
  care,
  medical,
  medication,
  vaccine,
  other,
}

enum RepeatInterval {
  threeHours,
  daily,
  weekly,
  monthly,
}

class Reminder {
  final String id;
  final String title;
  final DateTime date;
  final String description;
  bool isCompleted;
  final ReminderCategory category;
  final RepeatInterval? repeatInterval;
  
  Reminder({
    required this.id,
    required this.title,
    required this.date,
    required this.description,
    required this.isCompleted,
    required this.category,
    this.repeatInterval,
  });
}

class MedicalPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF0277BD).withOpacity(0.1)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final spacing = 40.0;
    
    // Draw plus symbols pattern
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        // Horizontal line
        canvas.drawLine(
          Offset(x - 5, y),
          Offset(x + 5, y),
          paint,
        );
        
        // Vertical line
        canvas.drawLine(
          Offset(x, y - 5),
          Offset(x, y + 5),
          paint,
        );
      }
    }
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class WavePainter extends CustomPainter {
  final List<Color> colors;
  
  WavePainter({required this.colors});
  
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: colors,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;
    
    final path = Path();
    
    path.moveTo(0, 0);
    path.lineTo(0, size.height * 0.5);
    
    // First wave
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height * 0.4,
      size.width * 0.5,
      size.height * 0.5,
    );
    
    // Second wave
    path.quadraticBezierTo(
      size.width * 0.75,
      size.height * 0.6,
      size.width,
      size.height * 0.5,
    );
    
    path.lineTo(size.width, 0);
    path.close();
    
    canvas.drawPath(path, paint);
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

