import 'package:flutter/material.dart';

class ClinicAppointmentDetailScreen extends StatefulWidget {
  const ClinicAppointmentDetailScreen({super.key});

  @override
  State<ClinicAppointmentDetailScreen> createState() => _ClinicAppointmentDetailScreenState();
}

class _ClinicAppointmentDetailScreenState extends State<ClinicAppointmentDetailScreen> {
  final List<Appointment> _appointments = [
    Appointment(
      id: '1',
      doctorName: 'Dra. Sarah Johnson',
      specialty: 'Pediatra',
      date: '15/03/2025',
      time: '10:30',
      status: AppointmentStatus.scheduled,
      notes: 'Consulta de rotina para acompanhamento do desenvolvimento.',
      vaccinesApplied: [],
    ),
    Appointment(
      id: '2',
      doctorName: 'Dr. Michael Chen',
      specialty: 'Pediatra',
      date: '15/02/2025',
      time: '09:00',
      status: AppointmentStatus.completed,
      notes: 'Bebê apresentou bom desenvolvimento. Peso: 3.6kg, Altura: 51cm.',
      vaccinesApplied: [
        'BCG',
        'Hepatite B (1ª dose)',
      ],
    ),
    Appointment(
      id: '3',
      doctorName: 'Dra. Emily Rodriguez',
      specialty: 'Pediatra',
      date: '15/01/2025',
      time: '11:15',
      status: AppointmentStatus.completed,
      notes: 'Primeira consulta após nascimento. Bebê saudável. Peso: 3.2kg, Altura: 49cm.',
      vaccinesApplied: [
        'Hepatite B (dose ao nascer)',
      ],
    ),
  ];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text('Consultas Médicas'),
      ),
      body: Stack(
        children: [
          // Medical pattern background
          Positioned.fill(
            child: CustomPaint(
              painter: MedicalPatternPainter(),
            ),
          ),
          
          // Top decoration
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: WavePainter(
                colors: [
                  Color(0xFF0277BD).withOpacity(0.15),
                  Color(0xFF00BCD4).withOpacity(0.15),
                ],
              ),
              size: Size(MediaQuery.of(context).size.width, 200),
            ),
          ),
          
          // Content
          ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: _appointments.length,
            itemBuilder: (context, index) {
              final appointment = _appointments[index];
              return _buildAppointmentCard(appointment);
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFF0277BD),
        child: Icon(Icons.add, color: Colors.white),
        onPressed: () {
          // Add appointment logic
        },
      ),
    );
  }
  
  Widget _buildAppointmentCard(Appointment appointment) {
    Color statusColor;
    String statusText;
    
    switch (appointment.status) {
      case AppointmentStatus.scheduled:
        statusColor = Color(0xFF0277BD);
        statusText = 'Agendada';
        break;
      case AppointmentStatus.completed:
        statusColor = Color(0xFF4CAF50);
        statusText = 'Realizada';
        break;
      case AppointmentStatus.cancelled:
        statusColor = Colors.red;
        statusText = 'Cancelada';
        break;
    }
    
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Appointment header
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.medical_services,
                    color: statusColor,
                    size: 20,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        appointment.doctorName,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Color(0xFF333333),
                        ),
                      ),
                      Text(
                        appointment.specialty,
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: statusColor,
                      width: 1,
                    ),
                  ),
                  child: Text(
                    statusText,
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // Appointment details
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      color: Colors.grey[600],
                      size: 20,
                    ),
                    SizedBox(width: 8),
                    Text(
                      appointment.date,
                      style: TextStyle(
                        fontSize: 15,
                        color: Color(0xFF333333),
                      ),
                    ),
                    SizedBox(width: 24),
                    Icon(
                      Icons.access_time,
                      color: Colors.grey[600],
                      size: 20,
                    ),
                    SizedBox(width: 8),
                    Text(
                      appointment.time,
                      style: TextStyle(
                        fontSize: 15,
                        color: Color(0xFF333333),
                      ),
                    ),
                  ],
                ),
                
                SizedBox(height: 16),
                
                Text(
                  'Observações Médicas:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Color(0xFF333333),
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  appointment.notes,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[700],
                    height: 1.5,
                  ),
                ),
                
                if (appointment.vaccinesApplied.isNotEmpty) ...[
                  SizedBox(height: 16),
                  Text(
                    'Vacinas Aplicadas:',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: Color(0xFF333333),
                    ),
                  ),
                  SizedBox(height: 8),
                  ...appointment.vaccinesApplied.map((vaccine) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 4.0),
                      child: Row(
                        children: [
                          Icon(
                            Icons.check_circle,
                            color: Color(0xFF4CAF50),
                            size: 16,
                          ),
                          SizedBox(width: 8),
                          Text(
                            vaccine,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[700],
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ],
              ],
            ),
          ),
          
          // Appointment actions
          if (appointment.status == AppointmentStatus.scheduled)
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  OutlinedButton(
                    onPressed: () {},
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.red,
                      side: BorderSide(color: Colors.red),
                    ),
                    child: Text('Cancelar'),
                  ),
                  SizedBox(width: 12),
                  ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF0277BD),
                    ),
                    child: Text('Reagendar'),
                  ),
                ],
              ),
            ),
          
          if (appointment.status == AppointmentStatus.completed)
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton.icon(
                    onPressed: () {},
                    icon: Icon(
                      Icons.description,
                      size: 18,
                      color: Color(0xFF0277BD),
                    ),
                    label: Text('Ver Relatório'),
                    style: TextButton.styleFrom(
                      foregroundColor: Color(0xFF0277BD),
                    ),
                  ),
                  SizedBox(width: 8),
                  TextButton.icon(
                    onPressed: () {},
                    icon: Icon(
                      Icons.share,
                      size: 18,
                      color: Colors.grey[600],
                    ),
                    label: Text('Compartilhar'),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

enum AppointmentStatus {
  scheduled,
  completed,
  cancelled,
}

class Appointment {
  final String id;
  final String doctorName;
  final String specialty;
  final String date;
  final String time;
  final AppointmentStatus status;
  final String notes;
  final List<String> vaccinesApplied;
  
  Appointment({
    required this.id,
    required this.doctorName,
    required this.specialty,
    required this.date,
    required this.time,
    required this.status,
    required this.notes,
    required this.vaccinesApplied,
  });
}

class MedicalPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF0277BD).withOpacity(0.1)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final spacing = 40.0;
    
    // Draw plus symbols pattern
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        // Horizontal line
        canvas.drawLine(
          Offset(x - 5, y),
          Offset(x + 5, y),
          paint,
        );
        
        // Vertical line
        canvas.drawLine(
          Offset(x, y - 5),
          Offset(x, y + 5),
          paint,
        );
      }
    }
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class WavePainter extends CustomPainter {
  final List<Color> colors;
  
  WavePainter({required this.colors});
  
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: colors,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;
    
    final path = Path();
    
    path.moveTo(0, 0);
    path.lineTo(0, size.height * 0.5);
    
    // First wave
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height * 0.4,
      size.width * 0.5,
      size.height * 0.5,
    );
    
    // Second wave
    path.quadraticBezierTo(
      size.width * 0.75,
      size.height * 0.6,
      size.width,
      size.height * 0.5,
    );
    
    path.lineTo(size.width, 0);
    path.close();
    
    canvas.drawPath(path, paint);
  }
  
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

