import 'package:supabase_flutter/supabase_flutter.dart';
import '../main.dart';
import 'dart:io' as io;
import 'package:path/path.dart' as path;
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';

// Classe para armazenar os dados do bebê de forma centralizada
class BabyData {
  static final BabyData _instance = BabyData._internal();
  
  factory BabyData() {
    return _instance;
  }
  
  BabyData._internal();
  
  // Dados do bebê
  String id = "";
  String name = "Lucas Silva";
  String birthDate = "10/01/2025";
  String gender = "Masculino";
  double weight = 3.8;
  double height = 52.0;
  String bloodType = "O+";
  String imageUrl = "https://randomuser.me/api/portraits/babies/1.jpg";
  List<String> allergies = [];
  String observations = "";
  
  // Método para notificar ouvintes quando os dados são atualizados
  final List<Function()> _listeners = [];
  
  void addListener(Function() listener) {
    _listeners.add(listener);
  }
  
  void removeListener(Function() listener) {
    _listeners.remove(listener);
  }
  
  void notifyListeners() {
    for (var listener in _listeners) {
      listener();
    }
  }
  
  // Método para carregar dados do Supabase
  Future<void> loadFromSupabase() async {
    try {
      final userId = supabase.auth.currentUser?.id;
      if (userId == null) return;
      
      final data = await supabase
          .from('babies')
          .select()
          .eq('user_id', userId)
          .maybeSingle();
      
      if (data != null) {
        id = data['id'] as String;
        name = data['name'] as String? ?? name;
        birthDate = data['birth_date'] as String? ?? birthDate;
        gender = data['gender'] as String? ?? gender;
        weight = (data['weight'] as num?)?.toDouble() ?? weight;
        height = (data['height'] as num?)?.toDouble() ?? height;
        bloodType = data['blood_type'] as String? ?? bloodType;
        imageUrl = data['image_url'] as String? ?? imageUrl;
        observations = data['observations'] as String? ?? observations;
        
        final allergiesData = await supabase
            .from('baby_allergies')
            .select('allergy')
            .eq('baby_id', id);
        
        allergies = allergiesData.map<String>((item) => item['allergy'] as String).toList();
      } else {
        final newBaby = {
          'user_id': userId,
          'name': name,
          'birth_date': birthDate,
          'gender': gender,
          'weight': weight,
          'height': height,
          'blood_type': bloodType,
          'image_url': imageUrl,
          'observations': observations,
        };
        
        final response = await supabase.from('babies').insert(newBaby).select();
        if (response.isNotEmpty) {
          id = response[0]['id'] as String;
        }
      }
      
      notifyListeners();
    } catch (e) {
      print('Erro ao carregar dados do bebê: $e');
    }
  }
  
  // Método para atualizar todos os dados de uma vez no Supabase
  Future<void> updateData({
    String? name,
    String? birthDate,
    String? gender,
    double? weight,
    double? height,
    String? bloodType,
    String? imageUrl,
    List<String>? allergies,
    String? observations,
  }) async {
    this.name = name ?? this.name;
    this.birthDate = birthDate ?? this.birthDate;
    this.gender = gender ?? this.gender;
    this.weight = weight ?? this.weight;
    this.height = height ?? this.height;
    this.bloodType = bloodType ?? this.bloodType;
    this.imageUrl = imageUrl ?? this.imageUrl;
    this.observations = observations ?? this.observations;
    
    if (allergies != null) {
      this.allergies = allergies;
    }
    
    try {
      final userId = supabase.auth.currentUser?.id;
      if (userId == null) return;
      
      if (id.isEmpty) {
        final newBaby = {
          'user_id': userId,
          'name': this.name,
          'birth_date': this.birthDate,
          'gender': this.gender,
          'weight': this.weight,
          'height': this.height,
          'blood_type': this.bloodType,
          'image_url': this.imageUrl,
          'observations': this.observations,
        };
        
        final response = await supabase.from('babies').insert(newBaby).select();
        if (response.isNotEmpty) {
          id = response[0]['id'] as String;
        }
      } else {
        await supabase.from('babies').update({
          'name': this.name,
          'birth_date': this.birthDate,
          'gender': this.gender,
          'weight': this.weight,
          'height': this.height,
          'blood_type': this.bloodType,
          'image_url': this.imageUrl,
          'observations': this.observations,
        }).eq('id', id);
      }
      
      if (allergies != null) {
        await supabase.from('baby_allergies').delete().eq('baby_id', id);
        
        if (this.allergies.isNotEmpty) {
          final allergyRecords = this.allergies.map((allergy) => {
            'baby_id': id,
            'allergy': allergy,
          }).toList();
          
          await supabase.from('baby_allergies').insert(allergyRecords);
        }
      }
      
      notifyListeners();
    } catch (e) {
      print('Erro ao atualizar dados do bebê: $e');
      throw e;
    }
  }
  
  // Método para fazer upload de imagem para o Supabase Storage usando API REST
  Future<String> uploadImage(String filePath) async {
    try {
      final userId = supabase.auth.currentUser?.id;
      if (userId == null) throw Exception('Usuário não autenticado');
      
      final fileName = 'baby_${DateTime.now().millisecondsSinceEpoch}${path.extension(filePath)}';
      final storagePath = '$userId/$fileName';
      
      // Obter o token de acesso
      final token = supabase.auth.currentSession?.accessToken;
      if (token == null) throw Exception('Token de acesso não disponível');
      
      // Construir a URL do bucket
      final bucketId = 'babyimage';
      final projectUrl = supabase.supabaseUrl;
      final storageUrl = '$projectUrl/storage/v1/object/$bucketId/$storagePath';
      
      // Determinar o tipo MIME
      final mimeType = lookupMimeType(filePath) ?? 'image/jpeg';
      
      // Ler o arquivo como bytes
      final bytes = await io.File(filePath).readAsBytes();
      
      // Fazer o upload usando HTTP
      final response = await http.put(
        Uri.parse(storageUrl),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': mimeType,
        },
        body: bytes,
      );
      
      if (response.statusCode != 200) {
        throw Exception('Falha no upload: ${response.statusCode} ${response.body}');
      }
      
      // Obter a URL pública usando o método do Supabase
      final imageUrl = supabase.storage.from('babyimage').getPublicUrl(storagePath);
      return imageUrl;
    } catch (e) {
      print('Erro ao fazer upload da imagem: $e');
      throw e;
    }
  }
}

