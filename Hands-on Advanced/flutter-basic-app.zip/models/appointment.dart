enum AppointmentStatus {
  confirmed,
  pending,
  completed,
  cancelled,
}

class Appointment {
  final String id;
  final String doctorName;
  final String doctorSpecialty;
  final String doctorImage;
  final DateTime date;
  final String time;
  final String reason;
  final AppointmentStatus status;

  Appointment({
    required this.id,
    required this.doctorName,
    required this.doctorSpecialty,
    required this.doctorImage,
    required this.date,
    required this.time,
    required this.reason,
    required this.status,
  });
}

