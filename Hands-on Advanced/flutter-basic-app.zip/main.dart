import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/splash_screen.dart';
import 'screens/dashboard_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://rcddasfiruszqnaltqnc.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJjZGRhc2ZpcnVzenFuYWx0cW5jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE4NzUyODIsImV4cCI6MjA1NzQ1MTI4Mn0.Lfx4gar3JBrt1TSEW3nrRNN3HQiVkJhHxK2BcQ5kW-g',
  );

  runApp(const BabySafeApp());
}

final supabase = Supabase.instance.client;

class BabySafeApp extends StatelessWidget {
  const BabySafeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BabySafe',
      theme: ThemeData(
        primaryColor: Color(0xFF0277BD),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0277BD),
          secondary: const Color(0xFF00BCD4),
          tertiary: const Color(0xFF4CAF50),
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: IconThemeData(color: Color(0xFF0277BD)),
          titleTextStyle: TextStyle(
            color: Color(0xFF0277BD),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF0277BD),
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            minimumSize: Size(double.infinity, 56),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: Color(0xFF0277BD),
            side: BorderSide(color: Color(0xFF0277BD), width: 1.5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            minimumSize: Size(double.infinity, 56),
          ),
        ),
      ),
      home: const SplashScreen(),
      routes: {
        '/dashboard': (context) => const DashboardScreen(),
      },
    );
  }
}

// Extension para mostrar SnackBar facilmente em qualquer contexto
extension ContextExtension on BuildContext {
  void showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(this).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError
            ? Theme.of(this).colorScheme.error
            : Theme.of(this).colorScheme.secondary,
      ),
    );
  }
}

