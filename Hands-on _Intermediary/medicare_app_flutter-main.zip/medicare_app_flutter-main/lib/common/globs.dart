class Globs {
  static const appName = "Medicare";
}